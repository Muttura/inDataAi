import { NgModule } from '@angular/core';
import { PreloadAllModules, RouterModule, Routes } from '@angular/router';

const routes: Routes = [
  {
    path: 'home',
    loadChildren: () => import('./home/home.module').then( m => m.HomePageModule)
  },
  {
    path: '',
    redirectTo: 'home',
    pathMatch: 'full'
  },
  {
    path: 'about',
    loadChildren: () => import('./about/about.module').then( m => m.AboutPageModule)
  },
  {
    path: 'download',
    loadChildren: () => import('./download/download.module').then( m => m.DownloadPageModule)
  },
  {
    path: 'gallary',
    loadChildren: () => import('./gallary/gallary.module').then( m => m.GallaryPageModule)
  },
  {
    path: 'songs',
    loadChildren: () => import('./songs/songs.module').then( m => m.SongsPageModule)
  },
  {
    path: 'stotra',
    loadChildren: () => import('./stotra/stotra.module').then( m => m.StotraPageModule)
  },
  {
    path: 'social-card',
    loadChildren: () => import('./social-card/social-card.module').then( m => m.SocialCardPageModule)
  },
  {
    path: 'download2',
    loadChildren: () => import('./download2/download2.module').then( m => m.Download2PageModule)
  },
  {
    path: 'download3',
    loadChildren: () => import('./download3/download3.module').then( m => m.Download3PageModule)
  },
  {
    path: 'download4',
    loadChildren: () => import('./download4/download4.module').then( m => m.Download4PageModule)
  },
  {
    path: 'download5',
    loadChildren: () => import('./download5/download5.module').then( m => m.Download5PageModule)
  },
  {
    path: 'download6',
    loadChildren: () => import('./download6/download6.module').then( m => m.Download6PageModule)
  },
  {
    path: 'download7',
    loadChildren: () => import('./download7/download7.module').then( m => m.Download7PageModule)
  },
  {
    path: 'download8',
    loadChildren: () => import('./download8/download8.module').then( m => m.Download8PageModule)
  },
  {
    path: 'download9',
    loadChildren: () => import('./download9/download9.module').then( m => m.Download9PageModule)
  },
  {
    path: 'home1',
    loadChildren: () => import('./home1/home1.module').then( m => m.Home1PageModule)
  },
  {
    path: 'home2',
    loadChildren: () => import('./home2/home2.module').then( m => m.Home2PageModule)
  },
  {
    path: 'download10',
    loadChildren: () => import('./download10/download10.module').then( m => m.Download10PageModule)
  },
  {
    path: 'download11',
    loadChildren: () => import('./download11/download11.module').then( m => m.Download11PageModule)
  },
  {
    path: 'download12',
    loadChildren: () => import('./download12/download12.module').then( m => m.Download12PageModule)
  },
  {
    path: 'download13',
    loadChildren: () => import('./download13/download13.module').then( m => m.Download13PageModule)
  },
];

@NgModule({
  imports: [
    RouterModule.forRoot(routes, { preloadingStrategy: PreloadAllModules })
  ],
  exports: [RouterModule]
})
export class AppRoutingModule { }
