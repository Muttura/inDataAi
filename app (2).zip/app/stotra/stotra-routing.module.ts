import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { StotraPage } from './stotra.page';

const routes: Routes = [
  {
    path: '',
    component: StotraPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class StotraPageRoutingModule {}
