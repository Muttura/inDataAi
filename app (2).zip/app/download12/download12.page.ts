import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-download12',
  templateUrl: './download12.page.html',
  styleUrls: ['./download12.page.scss'],
})
export class Download12Page implements OnInit {
  students: any;

  constructor() { }

  ngOnInit() {

    fetch('./assets/data/santhynarayan.json').then(res => res.json())
    .then(json => {
      
      this.students= json;
    });
  }

}
