import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { Download12PageRoutingModule } from './download12-routing.module';

import { Download12Page } from './download12.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    Download12PageRoutingModule
  ],
  declarations: [Download12Page]
})
export class Download12PageModule {}
