import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { Download12Page } from './download12.page';

describe('Download12Page', () => {
  let component: Download12Page;
  let fixture: ComponentFixture<Download12Page>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Download12Page ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(Download12Page);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
