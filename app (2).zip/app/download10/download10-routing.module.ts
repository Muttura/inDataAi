import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { Download10Page } from './download10.page';

const routes: Routes = [
  {
    path: '',
    component: Download10Page
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class Download10PageRoutingModule {}
