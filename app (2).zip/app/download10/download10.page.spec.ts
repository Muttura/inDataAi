import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { Download10Page } from './download10.page';

describe('Download10Page', () => {
  let component: Download10Page;
  let fixture: ComponentFixture<Download10Page>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Download10Page ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(Download10Page);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
