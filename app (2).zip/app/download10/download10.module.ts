import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { Download10PageRoutingModule } from './download10-routing.module';

import { Download10Page } from './download10.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    Download10PageRoutingModule
  ],
  declarations: [Download10Page]
})
export class Download10PageModule {}
