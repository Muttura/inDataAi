import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-download10',
  templateUrl: './download10.page.html',
  styleUrls: ['./download10.page.scss'],
})
export class Download10Page implements OnInit {
  students: any;

  constructor() { }

  ngOnInit() {
    fetch('./assets/data/LAGNAKE.json').then(res => res.json())
    .then(json => {
      
      this.students= json;
    });
  }
   
    
  }


