import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { Download8PageRoutingModule } from './download8-routing.module';

import { Download8Page } from './download8.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    Download8PageRoutingModule
  ],
  declarations: [Download8Page]
})
export class Download8PageModule {}
