import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { Download8Page } from './download8.page';

describe('Download8Page', () => {
  let component: Download8Page;
  let fixture: ComponentFixture<Download8Page>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Download8Page ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(Download8Page);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
