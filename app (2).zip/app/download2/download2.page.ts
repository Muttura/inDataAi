import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-download2',
  templateUrl: './download2.page.html',
  styleUrls: ['./download2.page.scss'],
})
export class Download2Page implements OnInit {
  [x: string]: any;

  
  ngOnInit() {

    fetch('./assets/data/students1.json').then(res => res.json())
    .then(json => {

      this.students= json;
    });
  }

}
