import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { Download9Page } from './download9.page';

describe('Download9Page', () => {
  let component: Download9Page;
  let fixture: ComponentFixture<Download9Page>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Download9Page ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(Download9Page);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
