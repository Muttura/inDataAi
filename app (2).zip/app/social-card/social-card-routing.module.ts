import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { SocialCardPage } from './social-card.page';

const routes: Routes = [
  {
    path: '',
    component: SocialCardPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class SocialCardPageRoutingModule {}
