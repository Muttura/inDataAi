import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { Download5PageRoutingModule } from './download5-routing.module';

import { Download5Page } from './download5.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    Download5PageRoutingModule
  ],
  declarations: [Download5Page]
})
export class Download5PageModule {}
