import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { Download5Page } from './download5.page';

describe('Download5Page', () => {
  let component: Download5Page;
  let fixture: ComponentFixture<Download5Page>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Download5Page ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(Download5Page);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
