import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { Download11Page } from './download11.page';

describe('Download11Page', () => {
  let component: Download11Page;
  let fixture: ComponentFixture<Download11Page>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Download11Page ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(Download11Page);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
