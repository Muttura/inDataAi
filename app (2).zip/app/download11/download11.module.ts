import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { Download11PageRoutingModule } from './download11-routing.module';

import { Download11Page } from './download11.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    Download11PageRoutingModule
  ],
  declarations: [Download11Page]
})
export class Download11PageModule {}
