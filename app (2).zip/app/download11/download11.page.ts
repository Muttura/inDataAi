import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-download11',
  templateUrl: './download11.page.html',
  styleUrls: ['./download11.page.scss'],
})
export class Download11Page implements OnInit {
  students: any;

  constructor() { }

  ngOnInit() {
    fetch('./assets/data/BAGILUPOOJA.json').then(res => res.json())
    .then(json => {
      
      this.students= json;
    });
  }
   
}
