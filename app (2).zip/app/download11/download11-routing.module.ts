import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { Download11Page } from './download11.page';

const routes: Routes = [
  {
    path: '',
    component: Download11Page
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class Download11PageRoutingModule {}
