import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-download7',
  templateUrl: './download7.page.html',
  styleUrls: ['./download7.page.scss'],
})
export class Download7Page implements OnInit {
  students: any;

  constructor() { }
  
  ngOnInit() { 
    fetch('./assets/data/HUKTI.json').then(res => res.json())
    .then(json => {

      this.students= json;
    });
    
  }

}
