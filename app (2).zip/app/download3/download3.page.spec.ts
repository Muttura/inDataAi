import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { Download3Page } from './download3.page';

describe('Download3Page', () => {
  let component: Download3Page;
  let fixture: ComponentFixture<Download3Page>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Download3Page ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(Download3Page);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
