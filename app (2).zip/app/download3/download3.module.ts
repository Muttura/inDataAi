import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { Download3PageRoutingModule } from './download3-routing.module';

import { Download3Page } from './download3.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    Download3PageRoutingModule
  ],
  declarations: [Download3Page]
})
export class Download3PageModule {}
