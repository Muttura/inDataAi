import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { Download6PageRoutingModule } from './download6-routing.module';

import { Download6Page } from './download6.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    Download6PageRoutingModule
  ],
  declarations: [Download6Page]
})
export class Download6PageModule {}
