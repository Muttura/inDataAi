import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { Download6Page } from './download6.page';

const routes: Routes = [
  {
    path: '',
    component: Download6Page
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class Download6PageRoutingModule {}
