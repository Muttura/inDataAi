import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-download6',
  templateUrl: './download6.page.html',
  styleUrls: ['./download6.page.scss'],
})
export class Download6Page implements OnInit {
  students: any;

  constructor() { }

  ngOnInit() { 
    fetch('./assets/data/BHUMI.json').then(res => res.json())
    .then(json => {

      this.students= json;
    });
    
  }

}
