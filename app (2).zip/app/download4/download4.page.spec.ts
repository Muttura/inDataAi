import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { Download4Page } from './download4.page';

describe('Download4Page', () => {
  let component: Download4Page;
  let fixture: ComponentFixture<Download4Page>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Download4Page ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(Download4Page);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
