import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-download4',
  templateUrl: './download4.page.html',
  styleUrls: ['./download4.page.scss'],
})
export class Download4Page implements OnInit {
  [x: string]: any;

  constructor() { }

  ngOnInit() { 
    fetch('./assets/data/LAGNAKE.json').then(res => res.json())
    .then(json => {

      this.students= json;
    });
    
  }

}
