import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-download13',
  templateUrl: './download13.page.html',
  styleUrls: ['./download13.page.scss'],
})
export class Download13Page implements OnInit {
  students: any;

  constructor() { }

  ngOnInit() {


    fetch('./assets/data/grahapravesh.json').then(res => res.json())
    .then(json => {
      
      this.students= json;
    });
  }

}
