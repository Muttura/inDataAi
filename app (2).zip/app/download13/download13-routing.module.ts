import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { Download13Page } from './download13.page';

const routes: Routes = [
  {
    path: '',
    component: Download13Page
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class Download13PageRoutingModule {}
