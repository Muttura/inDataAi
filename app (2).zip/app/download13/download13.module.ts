import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { Download13PageRoutingModule } from './download13-routing.module';

import { Download13Page } from './download13.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    Download13PageRoutingModule
  ],
  declarations: [Download13Page]
})
export class Download13PageModule {}
