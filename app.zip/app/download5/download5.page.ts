import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-download5',
  templateUrl: './download5.page.html',
  styleUrls: ['./download5.page.scss'],
})
export class Download5Page implements OnInit {
  Angadi: any;
  BHUMI: any;
  students3: any;
  students: any;

  constructor() { }

  ngOnInit() {

    fetch('./assets/data/Angadi.json').then(res => res.json())
    .then(json => {

      this.students= json;
    });
  }

}