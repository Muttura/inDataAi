import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-social-card',
  templateUrl: './social-card.page.html',
  styleUrls: ['./social-card.page.scss'],
})
export class SocialCardPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
