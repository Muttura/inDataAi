import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { Download8Page } from './download8.page';

const routes: Routes = [
  {
    path: '',
    component: Download8Page
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class Download8PageRoutingModule {}
