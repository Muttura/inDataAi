import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-download8',
  templateUrl: './download8.page.html',
  styleUrls: ['./download8.page.scss'],
})
export class Download8Page implements OnInit {
  students: any;

  constructor() { }

  ngOnInit() 
  { 
    fetch('./assets/data/home.json').then(res => res.json())
    .then(json => {

      this.students= json;
    });
    
  }

}