import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-download3',
  templateUrl: './download3.page.html',
  styleUrls: ['./download3.page.scss'],
})
export class Download3Page implements OnInit {
  [x: string]: any;

  constructor() { }

  ngOnInit() {
    
    fetch('./assets/data/students2.json').then(res => res.json())
    .then(json => {

      this.students= json;
    });
  }

}
