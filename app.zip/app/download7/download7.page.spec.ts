import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { Download7Page } from './download7.page';

describe('Download7Page', () => {
  let component: Download7Page;
  let fixture: ComponentFixture<Download7Page>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Download7Page ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(Download7Page);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
