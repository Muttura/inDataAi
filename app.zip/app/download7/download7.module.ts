import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { Download7PageRoutingModule } from './download7-routing.module';

import { Download7Page } from './download7.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    Download7PageRoutingModule
  ],
  declarations: [Download7Page]
})
export class Download7PageModule {}
