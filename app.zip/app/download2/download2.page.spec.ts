import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { Download2Page } from './download2.page';

describe('Download2Page', () => {
  let component: Download2Page;
  let fixture: ComponentFixture<Download2Page>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Download2Page ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(Download2Page);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
