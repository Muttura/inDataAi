import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { StotraPageRoutingModule } from './stotra-routing.module';

import { StotraPage } from './stotra.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    StotraPageRoutingModule
  ],
  declarations: [StotraPage]
})
export class StotraPageModule {}
