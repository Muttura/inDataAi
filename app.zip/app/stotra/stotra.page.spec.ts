import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { StotraPage } from './stotra.page';

describe('StotraPage', () => {
  let component: StotraPage;
  let fixture: ComponentFixture<StotraPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ StotraPage ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(StotraPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
