import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-stotra',
  templateUrl: './stotra.page.html',
  styleUrls: ['./stotra.page.scss'],
})
export class StotraPage implements OnInit {

  constructor() {}
    
  option = {
    slidesPerView: 1.5,
    centeredSlides: true,
    loop: true,
    spaceBetween: 10,
    autoplay:true,
  }

  ngOnInit() {
  }

}
