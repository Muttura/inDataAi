import { Component, OnInit } from '@angular/core';


@Component({
  selector: 'app-download',
  templateUrl: './download.page.html',
  styleUrls: ['./download.page.scss'],
})
export class DownloadPage implements OnInit {
  [x: string]: any;

  constructor() { }

  ngOnInit() {

    fetch('./assets/data/students.json').then(res => res.json())
      .then(json => {

        this.students= json;
      });

  }

}
