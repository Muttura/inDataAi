import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { Download9Page } from './download9.page';

const routes: Routes = [
  {
    path: '',
    component: Download9Page
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class Download9PageRoutingModule {}
