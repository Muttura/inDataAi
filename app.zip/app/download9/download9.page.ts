import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-download9',
  templateUrl: './download9.page.html',
  styleUrls: ['./download9.page.scss'],
})
export class Download9Page implements OnInit {
  students: any;

  constructor() { }
  
  ngOnInit() 
  { 
    fetch('./assets/data/RUDRAABHIS.json').then(res => res.json())
    .then(json => {

      this.students= json;
    });
    
  }

}