import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { Download9PageRoutingModule } from './download9-routing.module';

import { Download9Page } from './download9.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    Download9PageRoutingModule
  ],
  declarations: [Download9Page]
})
export class Download9PageModule {}
