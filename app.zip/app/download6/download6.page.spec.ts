import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { Download6Page } from './download6.page';

describe('Download6Page', () => {
  let component: Download6Page;
  let fixture: ComponentFixture<Download6Page>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Download6Page ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(Download6Page);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
