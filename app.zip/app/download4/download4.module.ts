import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { Download4PageRoutingModule } from './download4-routing.module';

import { Download4Page } from './download4.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    Download4PageRoutingModule
  ],
  declarations: [Download4Page]
})
export class Download4PageModule {}
