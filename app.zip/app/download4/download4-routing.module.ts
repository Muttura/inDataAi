import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { Download4Page } from './download4.page';

const routes: Routes = [
  {
    path: '',
    component: Download4Page
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class Download4PageRoutingModule {}
